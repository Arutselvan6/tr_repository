package com.shoes.service;

import java.util.List;

import com.shoes.model.Customer;

public interface CustomerServDAO {

	public void addCustomer(Customer c);
	public void deleteCustomer(int id);
	public void updateCustomer(Customer c);
	public List<Customer> viewAllCustomers();
}

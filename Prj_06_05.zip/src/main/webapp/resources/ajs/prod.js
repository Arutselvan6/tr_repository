var app=angular.module('product',[]);
var p = [
         {
        	 id:201,
        	 name:'Joystick',
        	 price:2500
         },
         {
        	 id:202,
        	 name:'PS2',
        	 price:25000
         },
         {
        	 id:203,
        	 name:'Xbox',
        	 price:250000
         }
        ]; 
app.controller('ProductController',function(){
	this.products = p;
});
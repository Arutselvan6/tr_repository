package com.musichub.service;

import com.musichub.DAO.*;

public class ProductDAOFactory {
	
	private static final ProductDAO obj = new ProductDAOImpl();
	
	public static ProductDAO getProductDAO(){
		return obj;
	}
}

package com.musichub.DAO;

import com.musichub.model.Product;
import java.util.*;

public class ProductDAOImpl implements ProductDAO {

	Product p;
	List<Product>l = new ArrayList<Product>();
	
	public void addProduct() {
		p = new Product(121,"Json",12000);
		l.add(p);
		p = new Product(122,"Gson",24000);
		l.add(p);
		p = new Product(123,"Gison",10000);
		l.add(p);
	}

	/*public void delProduct(int id) {
	
		
	}*/

	public List<Product> viewProduct() {
		addProduct();
		return l;
	}

	/*public void updateProduct(int id) {
		// TODO Auto-generated method stub
		
	}*/

}

package com.musichub.DAO;

import com.musichub.model.*;
import java.util.*;

public interface ProductDAO {
	public void addProduct();
	//public void delProduct(int id);
	public List<Product> viewProduct();
	//public void updateProduct(int id);
}

package com.musichub.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.musichub.DAO.ProductDAO;
import com.musichub.service.ProductDAOFactory;


@Controller
public class SpringController {

	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView goHome(){
		return new ModelAndView("index");
	}
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView login(){
		return new ModelAndView("login");
	}
	
	@RequestMapping(value="/signup",method=RequestMethod.GET)
	public ModelAndView signup(){
		return new ModelAndView("signup");
	}
	
	@RequestMapping(value="/about",method=RequestMethod.GET)
	public ModelAndView about(){
		return new ModelAndView("about");
	}
	@RequestMapping(value="/productpage",method=RequestMethod.GET)
	public ModelAndView prd(){
		Gson g = new Gson();
		ProductDAO pd = ProductDAOFactory.getProductDAO();
		String a = g.toJson(pd.viewProduct());
		//System.out.println(a);
		ModelAndView m = new ModelAndView("productpage");
		m.addObject("data", a);
		return m;
	}
	@RequestMapping(value="/newpage",method=RequestMethod.GET)
	public ModelAndView fin(){
		return new ModelAndView("newpage");
	}
}
